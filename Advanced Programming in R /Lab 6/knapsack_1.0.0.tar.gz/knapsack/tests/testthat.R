library(testthat)
library(rSwedishParliamentVotations)

test_check("rSwedishParliamentVotations")
